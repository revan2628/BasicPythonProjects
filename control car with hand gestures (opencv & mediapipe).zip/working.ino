#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#define IN1 25
#define IN2 26
#define IN3 27
#define IN4 14

const char* ssid = "imthegoat";
const char* password = "revanisdumb";

AsyncWebServer server(80);

void forward(){
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

void backward(){
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

void stopcar(){
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

void right(){
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

void left(){
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  // everything to low
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);

  

  Serial.println("Connecting to WiFi...");
  WiFi.mode(WIFI_STA);

Serial.println("Starting WiFi...");
WiFi.begin(ssid, password);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 25) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED){
    Serial.println("Connected to Wifi");
    Serial.println("IP Address: ");
    Serial.println(WiFi.localIP());

    server.on("/forward", HTTP_GET, [](AsyncWebServerRequest *request){
      forward();
      request->send(200, "text/plain", "Moving forward");
    });
    server.on("/backward", HTTP_GET, [](AsyncWebServerRequest *request){
      backward();
      request->send(200, "text/plain", "Moving backward");
    });
    server.on("/left", HTTP_GET, [](AsyncWebServerRequest *request){
      stopcar();
      delay(100);
      left();
      request->send(200, "text/plain", "Moving left");
    });
    server.on("/right", HTTP_GET, [](AsyncWebServerRequest *request){
      stopcar();
      delay(100);
      right();
      request->send(200, "text/plain", "Moving right");
    });
    server.on("/stop", HTTP_GET, [](AsyncWebServerRequest *request){
      stopcar();
      request->send(200, "text/plain", "NOT moving");
    });
  
    server.begin();
    Serial.println("Server started");
  } else {
    Serial.println("\nFailed to connect to WiFi");
  }
}

void loop() {
}